package clientCommunication;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;
import java.util.Random;

public class User implements Serializable, ActionListener {
	// Private data fields for the username and password.
	private String username;
	private String password;
	private Long userID;
	public String[] cards;
	public int health;
	public int score;
	public String pick1;
	public String pick2;
	public String status;

	Random rand = new Random();
	String[] allCards = { "Fire", "Water", "Electricity", "Health" };

	public User() {
		cards = new String[] { "Unsure", "Unsure", "Unsure" };
		health = 100;
		score = 0;
	}

	// Getters for the username and password.
	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}

	public long getID() {
		return userID;
	}

	public String[] getCards() {
		return cards;
	}

	public int getHealth() {
		return health;
	}

	public int getScore() {
		return score;
	}

	public String getPick1() {
		return pick1;
	}

	public String getPick2() {
		return pick2;
	}

	public String getStatus() {
		return status;
	}

	// Setters for the username and password.
	public void setUsername(String username) {
		this.username = username;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setID(Long userID) {
		this.userID = userID;
	}

	public void setCards(String[] cards) {
		this.cards = cards;
	}

	public void setHealth(int health) {
		this.health = health;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public void setPick1(String pick1) {
		this.pick1 = pick1;
	}

	public void setPick2(String pick2) {
		this.pick2 = pick2;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String[] dealCards() {
		String cards[] = getCards();

		for (int i = 0; i < 3; i++) {
			if (cards[i] == "Unsure")
				cards[i] = allCards[rand.nextInt(4)];
		}

		return cards;
	}

	public void actionPerformed(ActionEvent ae) {
		String command = ae.getActionCommand();

		{

		}
	}

	// Constructor that initializes the username and password.
	public User(String username, String password) {
		setUsername(username);
		setPassword(password);
	}
}