package clientCommunication;

import java.io.Serializable;
import java.util.ArrayList;

public class GameData implements Serializable {
	private User player1;
	private User player2;
	private String[] cards;

	public GameData() {
		player1 = new User();
		player2 = new User();
	}

	public void setCards(long l, String[] cards) {
		if (player1.getID() == l) {
			player1.setCards(cards);
		} else if (player2.getID() == l) {
			player2.setCards(cards);
		}
	}

	public void setPlayer1(User player1) {
		this.player1 = player1;
	}

	public void setPlayer2(User player2) {
		this.player2 = player2;
	}

	public String[] getCards() {
		return cards;
	}

	public User getPlayer1() {
		return player1;
	}

	public User getPlayer2() {
		return player2;
	}

	public void resetGame() {
		player1.setHealth(100);
		player1.setHealth(100);
	}
}
