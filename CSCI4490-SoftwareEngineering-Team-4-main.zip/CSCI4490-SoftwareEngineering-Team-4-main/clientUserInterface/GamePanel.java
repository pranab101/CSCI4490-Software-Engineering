package clientUserInterface;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import clientCommunication.*;

public class GamePanel extends JPanel {

	private User player1;
	private User player2;

	boolean playerTurn = true;

	public GamePanel(GameControl gc) {
		JPanel north = new JPanel();
		JPanel east = new JPanel();
		JPanel west = new JPanel();
		JPanel center = new JPanel();
		JPanel container = new JPanel(new BorderLayout());

		player1 = new User();
		player2 = new User();

		player1.dealCards();
		player2.dealCards();

		setBackground(new Color(255, 255, 255));

		JLabel statusText = new JLabel("Score: " + player1.score + " - " + player2.score);
		north.add(statusText);

		// West - Wizard 1 HP and Cards
		JPanel westRowPanel = new JPanel(new GridLayout(0, 1));

		JLabel wizard1healthLabel = new JLabel("Wizard 1 - " + player1.health + " HP");
		westRowPanel.add(wizard1healthLabel);

		JLabel wizard1card1 = new JLabel("");
		wizard1card1.setIcon(
				new ImageIcon(GamePanel.class.getResource("/clientUserInterface/" + player1.cards[0] + ".png")));
		westRowPanel.add(wizard1card1);

		JLabel wizard1card2 = new JLabel("");
		wizard1card2.setIcon(
				new ImageIcon(GamePanel.class.getResource("/clientUserInterface/" + player1.cards[1] + ".png")));
		westRowPanel.add(wizard1card2);

		JLabel wizard1card3 = new JLabel("");
		wizard1card3.setIcon(
				new ImageIcon(GamePanel.class.getResource("/clientUserInterface/" + player1.cards[2] + ".png")));
		westRowPanel.add(wizard1card3);

		west.add(westRowPanel);

		// Center - Wizard Icon, Statuses, and Card Selections
		JPanel centerGrid = new JPanel(new GridLayout(4, 1));

		JLabel wizardIcon = new JLabel("");
		wizardIcon.setIcon(new ImageIcon(GamePanel.class.getResource("/clientUserInterface/wizardclear.png")));
		centerGrid.add(wizardIcon);

		JPanel cardChoicePanel = new JPanel(new GridLayout(2, 1));
		cardChoicePanel.setSize(300, 50);

		JLabel card1choice = new JLabel("Card 1:");
		cardChoicePanel.add(card1choice);

		JComboBox<String> card1options = new JComboBox();
		JComboBox card2options = new JComboBox();

		DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>(player1.cards);
		card1options.setModel(model);

		ActionListener changeSecondSelection = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent ae) {
				// TODO Auto-generated method stub
				if (playerTurn == true) {
					player1.cards[card1options.getSelectedIndex()] = "Unsure";
					DefaultComboBoxModel<String> model2 = new DefaultComboBoxModel<>(player1.cards);
					card2options.setModel(model2);
					player1.setPick1(card1options.getSelectedItem().toString());
				} else {
					player2.cards[card1options.getSelectedIndex()] = "Unsure";
					DefaultComboBoxModel<String> model5 = new DefaultComboBoxModel<>(player2.cards);
					card2options.setModel(model5);
					player2.setPick1(card1options.getSelectedItem().toString());
				}
			}
		};

		card1options.addActionListener(changeSecondSelection);
		cardChoicePanel.add(card1options);

		JPanel card2choicePanel = new JPanel();
		card2choicePanel.setSize(300, 50);
		setLayout(new BorderLayout(0, 0));

		JLabel card2choice = new JLabel("Card 2:");
		cardChoicePanel.add(card2choice);
		cardChoicePanel.add(card2options);

		centerGrid.add(cardChoicePanel);

		JPanel statusBox = new JPanel();
		statusBox.setBorder(BorderFactory.createLineBorder(Color.black));
		statusBox.setLayout(new GridBagLayout());
		JLabel status = new JLabel();
		status.setText(player1.getStatus());

		statusBox.add(status);
		centerGrid.add(statusBox);

		JButton playAgain = new JButton("Play Again");
		JButton quitGame = new JButton("Quit Game");

		JLabel wizard2healthLabel = new JLabel("Wizard 2 - " + player2.health + " HP");
		// South - Play Hand / Play Again / Quit Game Buttons
		JPanel buttons = new JPanel(new GridLayout(3, 0));
		JButton playHand = new JButton("Play Hand");

		JLabel wizard2card1 = new JLabel("");
		JLabel wizard2card2 = new JLabel("");
		JLabel wizard2card3 = new JLabel("");

		playHand.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// If user presses the play hand

				if (playerTurn == true) {
					player1.setPick2(card2options.getSelectedItem().toString());
				} else {
					player2.setPick2(card2options.getSelectedItem().toString());
				}

				if (playerTurn == true) {
					if ((player1.pick1 == "Water" && player1.pick2 == "Electricity")
							|| (player1.pick1 == "Electricity" && player1.pick2 == "Water")) {
						if ((player2.health - 40) <= 0) {
							player1.setStatus("Wizard 1, you win!");
							player2.health = 0;
						} else {
							player2.health -= 40;
							player1.setStatus("Thunderstorm! Double damage.");
						}
						status.setText(player1.getStatus());
					} else if ((player1.pick1 == "Water" && player1.pick2 == "Fire")
							|| (player1.pick1 == "Fire" && player1.pick2 == "Water")) {
						if ((player2.health - 10) <= 0) {
							player1.setStatus("Wizard 1, you win!");
							player2.health = 0;
						} else
							player2.health -= 10;
						player1.setStatus("Water Vapor. Half damage...");
						status.setText(player1.getStatus());
					} else if ((player1.pick1 == "Health"
							&& (player1.pick2 == "Fire" || player1.pick2 == "Water" || player1.pick2 == "Electricity"))
							|| ((player1.pick1 == "Fire" || player1.pick1 == "Water" || player1.pick1 == "Electricity")
									&& player1.pick2 == "Health")) {
						if ((player1.health + 10) >= 100) {
							player1.health = 100;
							player1.setStatus("Healing attack! 10 health to Wizard 1 and 10 damage to Wizard 2.");
						} else
							player1.health += 10;
						player1.setStatus("Healing attack! 10 health to Wizard 1 and 10 damage to Wizard 2.");
						if ((player2.health - 10) <= 0) {
							player1.setStatus("Wizard 1, you win!");
							player2.health = 0;
						} else
							player2.health -= 10;
						status.setText(player1.getStatus());
					} else if ((player1.pick1 == "Health" && player1.pick2 == "Health")) {
						if ((player1.health + 30) >= 100) {
							player1.health = 100;
						} else
							player1.health += 30;
						player1.setStatus("Great heal! 30 health to yourself.");
						status.setText(player1.getStatus());
					} else {
						if ((player2.health - 20) <= 0) {
							player1.setStatus("Wizard 1, you win!");
							player2.health = 0;
						} else {
							player2.health -= 20;
							player1.setStatus("20 points of damage.");
						}
						status.setText(player1.getStatus());
					}
				} else {
					if ((player2.pick1 == "Water" && player2.pick2 == "Electricity")
							|| (player2.pick1 == "Electricity" && player2.pick2 == "Water")) {
						if ((player1.health - 40) <= 0) {
							player2.setStatus("Wizard 2, you win!");
							player1.health = 0;
						} else {
							player1.health -= 40;
							player2.setStatus("Thunderstorm! Double damage.");
						}
						status.setText(player2.getStatus());
					} else if ((player2.pick1 == "Water" && player2.pick2 == "Fire")
							|| (player2.pick1 == "Fire" && player2.pick2 == "Water")) {
						if ((player1.health - 10) <= 0) {
							player2.setStatus("Wizard 2, you win!");
							player1.health = 0;
						} else {
							player1.health -= 10;
							player2.setStatus("Water Vapor. Half damage...");
						}
						status.setText(player2.getStatus());
					} else if ((player2.pick1 == "Health"
							&& (player2.pick2 == "Fire" || player2.pick2 == "Water" || player2.pick2 == "Electricity"))
							|| ((player2.pick1 == "Fire" || player2.pick1 == "Water" || player2.pick1 == "Electricity")
									&& player2.pick2 == "Health")) {
						if ((player2.health + 10) >= 100) {
							player2.health = 100;
							player2.setStatus("Healing attack! 10 health to Wizard 2 and 10 damage to Wizard 1.");
						} else {
							player2.health += 10;
							player2.setStatus("Healing attack! 10 health to Wizard 2 and 10 damage to Wizard 1.");
						}
						if ((player1.health - 10) <= 0) {
							player2.setStatus("Wizard 2, you win!");
							player1.health = 0;
						} else
							player1.health -= 10;
						status.setText(player2.getStatus());
					} else if ((player2.pick1 == "Health" && player2.pick2 == "Health")) {
						if ((player2.health + 30) >= 100) {
							player2.health = 100;
						} else
							player2.health += 30;
						player2.setStatus("Great heal! 30 health to Wizard 2.");
						status.setText(player2.getStatus());
					} else {
						if ((player1.health - 20) <= 0) {
							player2.setStatus("Wizard 2, you win!");
							player1.health = 0;
						} else {
							player1.health -= 20;
							player2.setStatus("20 points of damage.");
						}
						status.setText(player2.getStatus());
					}
				}

				wizard1healthLabel.setText("Wizard 1 - " + player1.health + " HP");
				wizard2healthLabel.setText("Wizard 2 - " + player2.health + " HP");

				if (player2.health <= 0) {
					player1.setStatus("Wizard 1, you win!");
					status.setText(player1.getStatus());

					playHand.setVisible(false);
					quitGame.setVisible(true);
				}
				if (player1.health <= 0) {
					player2.setStatus("Wizard 2, you win!");
					status.setText(player2.getStatus());

					playHand.setVisible(false);
					quitGame.setVisible(true);
				}

				if (playerTurn == true)
					status.setText(player1.getStatus());
				else
					status.setText(player2.getStatus());

				playerTurn = !playerTurn;

				if (playerTurn == true) {
					String[] cards = player1.dealCards();

					player1.cards = cards;

					wizard1card1.setIcon(new ImageIcon(
							GamePanel.class.getResource("/clientUserInterface/" + player1.cards[0] + ".png")));
					wizard1card2.setIcon(new ImageIcon(
							GamePanel.class.getResource("/clientUserInterface/" + player1.cards[1] + ".png")));
					wizard1card3.setIcon(new ImageIcon(
							GamePanel.class.getResource("/clientUserInterface/" + player1.cards[2] + ".png")));

					DefaultComboBoxModel<String> model3 = new DefaultComboBoxModel<>(player1.cards);
					card1options.setModel(model3);
					card2options.removeAllItems();
				} else {
					String[] cards = player2.dealCards();

					player2.cards = cards;

					wizard2card1.setIcon(new ImageIcon(
							GamePanel.class.getResource("/clientUserInterface/" + player2.cards[0] + ".png")));
					wizard2card2.setIcon(new ImageIcon(
							GamePanel.class.getResource("/clientUserInterface/" + player2.cards[1] + ".png")));
					wizard2card3.setIcon(new ImageIcon(
							GamePanel.class.getResource("/clientUserInterface/" + player2.cards[2] + ".png")));

					DefaultComboBoxModel<String> model4 = new DefaultComboBoxModel<>(player2.cards);
					card1options.setModel(model4);
					card2options.removeAllItems();
				}
			}
		});
		buttons.add(playHand);

		playAgain.setVisible(false);
		buttons.add(playAgain);

		quitGame.setVisible(false);
		quitGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent xe) {
				System.exit(0);
			}
		});
		buttons.add(quitGame);

		centerGrid.add(buttons);

		center.add(centerGrid);

		// East - Wizard 2 HP and Cards
		JPanel eastRowPanel = new JPanel(new GridLayout(0, 1));

		eastRowPanel.add(wizard2healthLabel);

		wizard2card1.setIcon(
				new ImageIcon(GamePanel.class.getResource("/clientUserInterface/" + player2.cards[0] + ".png")));
		eastRowPanel.add(wizard2card1);

		wizard2card2.setIcon(
				new ImageIcon(GamePanel.class.getResource("/clientUserInterface/" + player2.cards[1] + ".png")));
		eastRowPanel.add(wizard2card2);

		wizard2card3.setIcon(
				new ImageIcon(GamePanel.class.getResource("/clientUserInterface/" + player2.cards[2] + ".png")));
		eastRowPanel.add(wizard2card3);

		east.add(eastRowPanel);

		container.add(north, BorderLayout.NORTH);
		container.add(east, BorderLayout.EAST);
		container.add(west, BorderLayout.WEST);
		container.add(center, BorderLayout.CENTER);

		this.add(container);

	}
}