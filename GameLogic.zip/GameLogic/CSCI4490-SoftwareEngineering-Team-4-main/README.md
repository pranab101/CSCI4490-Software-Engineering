"# CSCI4490-SoftwareEngineering-Team-4" 

Pranab Pudasaini, 
Daniel Freeman, 
Marissa Scroggins, 
Oliver Arce

Follow this order for proper launch:
1. run: GuWeeOhServer.bat
2. run: GuWeeOhClient.bat
   
   a. enter the IP address of the machine that GuWeeOhServer.bat is running on
   
   
   b. repeat for client 2
   
4. Login/Create account
