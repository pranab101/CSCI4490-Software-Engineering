"# CSCI4490-SoftwareEngineering-Team-4" 

Pranab Pudasaini, 
Daniel Freeman, 
Marissa Scroggins, 
Oliver Arce

Follow this order for proper launch:
1. run: xampp mySQL
2. In CMD login into xampp
   
   a. user=student
   
   b. password=hello
   
   c. SOURCE guweeohSQL
   
4. run: GuWeeOhServer.bat
5. run: GuWeeOhClient.bat

   a. enter the IP address of the machine that GuWeeOhServer.bat is running on

   b. repeat for client 2
   
7. Login/Create account
